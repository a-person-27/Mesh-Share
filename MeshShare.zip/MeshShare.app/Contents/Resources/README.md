# Mesh-Share

**Peer-to-peer LAN file sharing for macOS.**

## Setup

1. **Move** `MeshShare.app` to your `/Applications` folder (optional but recommended).
2. **Double-click** to launch.
3. On first launch, macOS may show a security warning:
   - Go to **System Settings → Privacy & Security** and click **"Open Anyway"**.

## Requirements

- macOS 10.14 Mojave or later
- Python 3 (pre-installed on macOS, or install via [python.org](https://python.org) / Homebrew)
- `zeroconf` Python package (the app will offer to install it on first launch)

  To install manually:
  ```
  pip3 install zeroconf --user
  ```

## How it works

- Mesh-Share auto-discovers peers on your local network using **mDNS/Bonjour** (no setup needed).
- Files you place in `~/MeshShare/` are shared with peers.
- **Double-click** a peer to browse their files.
- **Double-click** a file to download it.

## Sharing files

Place any files you want to share inside the **`~/MeshShare/`** folder  
(tap **📁 Open Shared Folder** in the app to open it in Finder).

## Notes

- All transfers are direct TCP — no internet, no cloud, no server.
- The app picks a random port between 50000–51000 each launch.
- For macOS 13+ you may need to allow Local Network access in **System Settings → Privacy & Security → Local Network**.
