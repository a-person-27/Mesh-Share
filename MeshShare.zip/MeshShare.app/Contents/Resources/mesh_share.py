import os
import sys
import socket
import threading
import json
import random
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path

# Try importing zeroconf
try:
    from zeroconf import Zeroconf, ServiceInfo, ServiceBrowser
    ZEROCONF_AVAILABLE = True
except ImportError:
    ZEROCONF_AVAILABLE = False

SERVICE_TYPE = "_p2pshare._tcp.local."
SHARED_FOLDER = str(Path.home() / "MeshShare")
BUFFER_SIZE = 65536

# ─────────────────────────────────────────
# Colour / style tokens (macOS feel)
# ─────────────────────────────────────────
BG        = "#1e1e2e"
SURFACE   = "#2a2a3e"
ACCENT    = "#7c6af7"        # purple
ACCENT2   = "#5ea8f7"        # blue
TEXT      = "#e0deff"
SUBTEXT   = "#8888aa"
GREEN     = "#4ade80"
RED       = "#f87171"
BORDER    = "#3a3a5c"


# ─────────────────────────────────────────
# Networking helpers
# ─────────────────────────────────────────

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


# ─────────────────────────────────────────
# mDNS peer discovery
# ─────────────────────────────────────────

class PeerListener:
    def __init__(self, on_change):
        self.peers = {}          # name -> (ip, port, hostname)
        self._on_change = on_change

    def remove_service(self, zc, type_, name):
        self.peers.pop(name, None)
        self._on_change()

    def update_service(self, zc, type_, name):
        self.add_service(zc, type_, name)

    def add_service(self, zc, type_, name):
        info = zc.get_service_info(type_, name)
        if info:
            addr = socket.inet_ntoa(info.addresses[0])
            hostname = info.server.rstrip(".")
            self.peers[name] = (addr, info.port, hostname)
            self._on_change()


# ─────────────────────────────────────────
# TCP server
# ─────────────────────────────────────────

def handle_client(conn):
    try:
        request = conn.recv(1024).decode()

        if request == "LIST":
            files = []
            for f in os.listdir(SHARED_FOLDER):
                fpath = os.path.join(SHARED_FOLDER, f)
                if os.path.isfile(fpath):
                    size = os.path.getsize(fpath)
                    files.append({"name": f, "size": size})
            conn.send(json.dumps(files).encode())

        elif request.startswith("GET "):
            filename = request[4:].strip()
            path = os.path.join(SHARED_FOLDER, filename)
            if os.path.isfile(path):
                conn.send(b"OK")
                size = os.path.getsize(path)
                conn.send(str(size).encode().ljust(20))
                with open(path, "rb") as f:
                    while chunk := f.read(BUFFER_SIZE):
                        conn.sendall(chunk)
            else:
                conn.send(b"NOTFOUND            ")
    except Exception:
        pass
    finally:
        conn.close()


def start_server(port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("0.0.0.0", port))
    server.listen(20)
    while True:
        try:
            conn, _ = server.accept()
            threading.Thread(target=handle_client, args=(conn,), daemon=True).start()
        except Exception:
            break


# ─────────────────────────────────────────
# TCP client helpers
# ─────────────────────────────────────────

def list_files(peer):
    ip, port, _ = peer
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(5)
    s.connect((ip, port))
    s.send(b"LIST")
    chunks = []
    while True:
        data = s.recv(65536)
        if not data:
            break
        chunks.append(data)
    s.close()
    return json.loads(b"".join(chunks).decode())


def download_file(peer, filename, save_path, progress_cb):
    ip, port, _ = peer
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(30)
    s.connect((ip, port))
    s.send(f"GET {filename}".encode())
    resp = s.recv(20)
    if not resp.startswith(b"OK"):
        s.close()
        return False
    size = int(s.recv(20).decode().strip())
    received = 0
    with open(save_path, "wb") as f:
        while received < size:
            chunk = s.recv(BUFFER_SIZE)
            if not chunk:
                break
            f.write(chunk)
            received += len(chunk)
            progress_cb(received, size)
    s.close()
    return received >= size


# ─────────────────────────────────────────
# Utility
# ─────────────────────────────────────────

def human_size(b):
    for unit in ("B", "KB", "MB", "GB"):
        if b < 1024:
            return f"{b:.1f} {unit}"
        b /= 1024
    return f"{b:.1f} TB"


# ─────────────────────────────────────────
# GUI
# ─────────────────────────────────────────

class MeshShareApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Mesh-Share")
        self.root.geometry("820x560")
        self.root.minsize(700, 480)
        self.root.configure(bg=BG)

        os.makedirs(SHARED_FOLDER, exist_ok=True)

        self.port = random.randint(50000, 51000)
        self.hostname = socket.gethostname().split(".")[0]
        self.ip = get_local_ip()

        self._peers_lock = threading.Lock()
        self._selected_peer = None
        self._file_entries = []        # list of {"name":…, "size":…}

        self._build_ui()
        self._start_network()
        self._auto_refresh()

    # ── Network bootstrap ────────────────

    def _start_network(self):
        threading.Thread(target=start_server, args=(self.port,), daemon=True).start()

        if not ZEROCONF_AVAILABLE:
            self._set_status("⚠️  zeroconf not installed — peer discovery disabled", RED)
            return

        self.zeroconf = Zeroconf()
        self.listener = PeerListener(on_change=self._schedule_peer_refresh)
        ServiceBrowser(self.zeroconf, SERVICE_TYPE, self.listener)

        info = ServiceInfo(
            SERVICE_TYPE,
            f"{self.hostname}.{SERVICE_TYPE}",
            addresses=[socket.inet_aton(self.ip)],
            port=self.port,
            properties={"hostname": self.hostname},
        )
        self.zeroconf.register_service(info)

    def _schedule_peer_refresh(self):
        self.root.after(0, self._refresh_peers)

    # ── UI construction ──────────────────

    def _build_ui(self):
        # ── Title bar area ───────────────
        header = tk.Frame(self.root, bg=BG, pady=12)
        header.pack(fill="x", padx=18)

        tk.Label(header, text="⬡  Mesh-Share", font=("SF Pro Display", 22, "bold"),
                 bg=BG, fg=ACCENT).pack(side="left")

        self._status_lbl = tk.Label(header, text="", font=("SF Pro Text", 11),
                                    bg=BG, fg=SUBTEXT)
        self._status_lbl.pack(side="right", pady=4)

        self._ip_lbl = tk.Label(header,
                                text=f"  {self.hostname}  ·  {self.ip}:{self.port}",
                                font=("SF Pro Text", 11), bg=BG, fg=SUBTEXT)
        self._ip_lbl.pack(side="right")

        # ── Divider ──────────────────────
        tk.Frame(self.root, bg=BORDER, height=1).pack(fill="x")

        # ── Main two-column area ─────────
        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=18, pady=12)
        body.columnconfigure(0, weight=1, minsize=220)
        body.columnconfigure(1, weight=2)
        body.rowconfigure(0, weight=1)

        # Left: peers
        left = tk.Frame(body, bg=SURFACE, bd=0, highlightthickness=1,
                        highlightbackground=BORDER)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))

        tk.Label(left, text="PEERS", font=("SF Pro Text", 10, "bold"),
                 bg=SURFACE, fg=SUBTEXT, anchor="w", padx=10, pady=8).pack(fill="x")
        tk.Frame(left, bg=BORDER, height=1).pack(fill="x")

        peer_scroll = tk.Scrollbar(left, orient="vertical")
        self._peer_lb = tk.Listbox(
            left, yscrollcommand=peer_scroll.set,
            bg=SURFACE, fg=TEXT, selectbackground=ACCENT,
            selectforeground="white", font=("SF Pro Text", 13),
            activestyle="none", bd=0, highlightthickness=0,
            relief="flat", cursor="hand2",
        )
        peer_scroll.config(command=self._peer_lb.yview)
        peer_scroll.pack(side="right", fill="y")
        self._peer_lb.pack(fill="both", expand=True)
        self._peer_lb.bind("<Double-Button-1>", lambda _: self._browse_peer())
        self._peer_lb.bind("<<ListboxSelect>>", self._on_peer_select)

        # Refresh button under peers
        btn_frame = tk.Frame(left, bg=SURFACE, pady=6)
        btn_frame.pack(fill="x")
        self._mk_btn(btn_frame, "↻  Refresh Peers", self._refresh_peers,
                     ACCENT).pack(padx=8, pady=2, fill="x")
        self._mk_btn(btn_frame, "📁  Open Shared Folder", self._open_shared_folder,
                     SURFACE, fg=ACCENT2).pack(padx=8, pady=(0, 4), fill="x")

        # Right: files
        right = tk.Frame(body, bg=SURFACE, bd=0, highlightthickness=1,
                         highlightbackground=BORDER)
        right.grid(row=0, column=1, sticky="nsew")

        file_hdr = tk.Frame(right, bg=SURFACE)
        file_hdr.pack(fill="x")
        tk.Label(file_hdr, text="FILES", font=("SF Pro Text", 10, "bold"),
                 bg=SURFACE, fg=SUBTEXT, anchor="w", padx=10, pady=8).pack(side="left")
        self._peer_title = tk.Label(file_hdr, text="(select a peer to browse)",
                                    font=("SF Pro Text", 11, "italic"),
                                    bg=SURFACE, fg=SUBTEXT)
        self._peer_title.pack(side="right", padx=10)

        tk.Frame(right, bg=BORDER, height=1).pack(fill="x")

        # File treeview (name + size)
        cols = ("name", "size")
        file_scroll = tk.Scrollbar(right, orient="vertical")
        self._file_tree = ttk.Treeview(
            right, columns=cols, show="headings",
            yscrollcommand=file_scroll.set, selectmode="browse",
        )
        self._file_tree.heading("name", text="File Name")
        self._file_tree.heading("size", text="Size")
        self._file_tree.column("name", stretch=True)
        self._file_tree.column("size", width=90, anchor="e", stretch=False)
        file_scroll.config(command=self._file_tree.yview)
        file_scroll.pack(side="right", fill="y")
        self._file_tree.pack(fill="both", expand=True)
        self._file_tree.bind("<Double-Button-1>", lambda _: self._download_selected())

        # Style treeview dark
        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview",
                        background=SURFACE, foreground=TEXT,
                        fieldbackground=SURFACE, rowheight=28,
                        font=("SF Pro Text", 12))
        style.configure("Treeview.Heading",
                        background=BG, foreground=SUBTEXT,
                        font=("SF Pro Text", 10, "bold"), relief="flat")
        style.map("Treeview", background=[("selected", ACCENT)])

        # Download button
        dl_bar = tk.Frame(right, bg=SURFACE, pady=6)
        dl_bar.pack(fill="x")
        self._mk_btn(dl_bar, "⬇  Download Selected", self._download_selected,
                     ACCENT2).pack(padx=8, pady=2, fill="x")

        # ── Bottom bar ───────────────────
        tk.Frame(self.root, bg=BORDER, height=1).pack(fill="x")

        bottom = tk.Frame(self.root, bg=BG, pady=8)
        bottom.pack(fill="x", padx=18)

        self._progress_var = tk.DoubleVar()
        self._progress = ttk.Progressbar(bottom, variable=self._progress_var,
                                         length=220, maximum=100)
        self._progress.pack(side="left")

        style.configure("TProgressbar", troughcolor=SURFACE,
                        background=ACCENT, thickness=8)

        self._dl_lbl = tk.Label(bottom, text="", font=("SF Pro Text", 11),
                                bg=BG, fg=SUBTEXT)
        self._dl_lbl.pack(side="left", padx=10)

    # ── Widget helpers ───────────────────

    def _mk_btn(self, parent, text, cmd, bg, fg="white"):
        return tk.Button(parent, text=text, command=cmd,
                         bg=bg, fg=fg, activebackground=ACCENT,
                         activeforeground="white",
                         font=("SF Pro Text", 12), bd=0,
                         relief="flat", cursor="hand2", pady=6)

    def _set_status(self, msg, color=SUBTEXT):
        self._status_lbl.config(text=msg, fg=color)

    # ── Peer list ────────────────────────

    def _auto_refresh(self):
        self._refresh_peers()
        self.root.after(4000, self._auto_refresh)

    def _refresh_peers(self):
        if not ZEROCONF_AVAILABLE:
            return
        current_sel = self._get_selected_peer_name()
        self._peer_lb.delete(0, tk.END)
        for name, (ip, port, hostname) in self.listener.peers.items():
            label = f"  {hostname or name.split('.')[0]}  ({ip})"
            self._peer_lb.insert(tk.END, label)
            self._peer_lb.itemconfig(tk.END, {"foreground": TEXT})

        if not self.listener.peers:
            self._peer_lb.insert(tk.END, "  No peers found…")
            self._peer_lb.itemconfig(0, {"foreground": SUBTEXT})

        self._set_status(f"● {len(self.listener.peers)} peer(s) on network", GREEN
                         if self.listener.peers else SUBTEXT)

    def _get_selected_peer_name(self):
        sel = self._peer_lb.curselection()
        if not sel:
            return None
        return sel[0]

    def _on_peer_select(self, _evt):
        pass  # Could auto-browse on single click; skipping for now

    def _get_selected_peer(self):
        sel = self._peer_lb.curselection()
        if not sel:
            return None
        idx = sel[0]
        peers = list(self.listener.peers.values())
        if idx < len(peers):
            return peers[idx]
        return None

    # ── File browsing ────────────────────

    def _browse_peer(self):
        peer = self._get_selected_peer()
        if not peer:
            return
        ip, port, hostname = peer
        self._peer_title.config(text=hostname or ip)
        self._set_status("Fetching file list…", ACCENT2)

        def task():
            try:
                files = list_files(peer)
                self.root.after(0, lambda: self._populate_files(files))
                self.root.after(0, lambda: self._set_status(
                    f"{len(files)} file(s) on {hostname}", GREEN))
            except Exception as e:
                self.root.after(0, lambda: self._set_status(
                    f"Failed to connect: {e}", RED))

        threading.Thread(target=task, daemon=True).start()

    def _populate_files(self, files):
        self._file_entries = files
        for item in self._file_tree.get_children():
            self._file_tree.delete(item)
        for f in files:
            name = f["name"] if isinstance(f, dict) else f
            size = human_size(f["size"]) if isinstance(f, dict) else ""
            self._file_tree.insert("", tk.END, values=(name, size))

    # ── Downloading ──────────────────────

    def _download_selected(self):
        peer = self._get_selected_peer()
        if not peer:
            messagebox.showinfo("Mesh-Share", "Please select a peer first.")
            return

        sel = self._file_tree.selection()
        if not sel:
            messagebox.showinfo("Mesh-Share", "Please select a file to download.")
            return

        values = self._file_tree.item(sel[0], "values")
        filename = values[0]

        save_path = filedialog.asksaveasfilename(
            initialfile=filename,
            initialdir=str(Path.home() / "Downloads"),
            title="Save downloaded file as…",
        )
        if not save_path:
            return

        self._progress_var.set(0)
        self._dl_lbl.config(text=f"Downloading {filename}…", fg=ACCENT2)

        def progress_cb(received, total):
            pct = (received / total) * 100
            self.root.after(0, lambda: self._progress_var.set(pct))
            self.root.after(0, lambda: self._dl_lbl.config(
                text=f"{human_size(received)} / {human_size(total)}"))

        def task():
            ok = download_file(peer, filename, save_path, progress_cb)
            msg = f"✓ {filename} saved" if ok else f"✗ Failed to download {filename}"
            color = GREEN if ok else RED
            self.root.after(0, lambda: self._dl_lbl.config(text=msg, fg=color))
            if ok:
                self.root.after(0, lambda: self._progress_var.set(100))

        threading.Thread(target=task, daemon=True).start()

    # ── Misc ─────────────────────────────

    def _open_shared_folder(self):
        os.makedirs(SHARED_FOLDER, exist_ok=True)
        if sys.platform == "darwin":
            os.system(f'open "{SHARED_FOLDER}"')
        else:
            os.system(f'xdg-open "{SHARED_FOLDER}"')


# ─────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────

if __name__ == "__main__":
    root = tk.Tk()
    root.createcommand("tk::mac::Quit", root.destroy)   # native ⌘Q on macOS
    app = MeshShareApp(root)
    root.mainloop()
