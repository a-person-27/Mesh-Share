# -*- mode: python ; coding: utf-8 -*-
# P2P LAN Share - PyInstaller spec for macOS

a = Analysis(
    ['p2p_lan_share.py'],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=[
        'zeroconf',
        'zeroconf._utils',
        'zeroconf._handlers',
        'zeroconf._protocol',
        'zeroconf._listener',
        'zeroconf._browser',
        'zeroconf._core',
        'zeroconf._engine',
        'zeroconf._record_update',
        'zeroconf._updates',
        'ifaddr',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='P2P LAN Share',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    target_arch=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='P2P LAN Share',
)

app = BUNDLE(
    coll,
    name='P2P LAN Share.app',
    icon=None,  # Set to 'icon.icns' if you have one
    bundle_identifier='com.p2planshare.app',
    info_plist={
        'CFBundleName': 'P2P LAN Share',
        'CFBundleDisplayName': 'P2P LAN Share',
        'CFBundleVersion': '1.0.0',
        'CFBundleShortVersionString': '1.0.0',
        'NSLocalNetworkUsageDescription': 'P2P LAN Share needs local network access to discover and connect to peers.',
        'NSBonjourServices': ['_p2pshare._tcp'],
        'LSMinimumSystemVersion': '10.13.0',
    },
)
