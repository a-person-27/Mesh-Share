# P2P LAN Share — macOS App Build

## Quick Start

1. Open Terminal and `cd` into this folder
2. Run the build script:

```bash
chmod +x build_macos.sh
./build_macos.sh
```

3. Your app will be at `dist/P2P LAN Share.app`
4. Drag it to `/Applications` to install

## What's Included

| File | Purpose |
|---|---|
| `p2p_lan_share.py` | Main application source |
| `P2PLANShare.spec` | PyInstaller build config |
| `build_macos.sh` | One-click build script |

## Requirements

- **macOS 10.13+**
- **Python 3.8+** — install from [python.org](https://www.python.org/downloads/) if needed
- The build script handles all other dependencies automatically via a virtual environment

## First Launch

macOS Gatekeeper will likely block the app since it's not code-signed. To open it:

1. **Right-click** the app → **Open** (first time only), or
2. Go to **System Settings → Privacy & Security** → click **Open Anyway**

## Optional: Add a Custom Icon

1. Create or find a 1024×1024 PNG icon
2. Convert it to `.icns` format (use an online converter or `iconutil`)
3. Place it in this folder as `icon.icns`
4. The spec file will pick it up automatically (uncomment the `icon=` line)

## Network Permissions

On first launch, macOS will ask to allow:
- **Incoming network connections** (for the file server)
- **Local network access** (for peer discovery via Bonjour/Zeroconf)

Both are required — click **Allow**.

## How It Works

- Peers are auto-discovered on your LAN via Zeroconf/Bonjour
- Double-click a peer to browse their shared files
- Double-click a file to download it
- Files in the `shared/` folder next to the app are served to other peers
