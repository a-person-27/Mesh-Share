#!/bin/bash
# ============================================
# Build P2P LAN Share as a macOS .app
# ============================================
# Run this script on your Mac:
#   chmod +x build_macos.sh
#   ./build_macos.sh
# ============================================

set -e

echo "🔧 Setting up build environment..."

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required. Install from https://python.org"
    exit 1
fi

# Create and activate virtual environment
python3 -m venv .venv
source .venv/bin/activate

echo "📦 Installing dependencies..."
pip install --upgrade pip
pip install pyinstaller zeroconf

echo "🏗️  Building macOS app..."
pyinstaller P2PLANShare.spec --clean --noconfirm

echo ""
echo "✅ Build complete!"
echo ""
echo "   Your app is at: dist/P2P LAN Share.app"
echo ""
echo "   To install, drag it to /Applications."
echo ""
echo "   ⚠️  On first launch, macOS may block it."
echo "      Go to System Settings → Privacy & Security → Open Anyway"
echo ""

# Optional: create a DMG
read -p "Create a DMG installer? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "📀 Creating DMG..."
    mkdir -p dmg_staging
    cp -R "dist/P2P LAN Share.app" dmg_staging/
    ln -sf /Applications dmg_staging/Applications

    hdiutil create -volname "P2P LAN Share" \
        -srcfolder dmg_staging \
        -ov -format UDZO \
        "dist/P2P_LAN_Share.dmg"

    rm -rf dmg_staging
    echo "✅ DMG created at: dist/P2P_LAN_Share.dmg"
fi

deactivate
