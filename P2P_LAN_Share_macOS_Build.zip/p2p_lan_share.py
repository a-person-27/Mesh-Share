import os
import socket
import threading
import json
import random
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from zeroconf import Zeroconf, ServiceInfo, ServiceBrowser

SERVICE_TYPE = "_p2pshare._tcp.local."
SHARED_FOLDER = "./shared"
BUFFER_SIZE = 65536


# -----------------------
# Networking
# -----------------------

def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    ip = s.getsockname()[0]
    s.close()
    return ip


class PeerListener:
    def __init__(self):
        self.peers = {}

    def remove_service(self, zeroconf, type, name):
        self.peers.pop(name, None)

    def add_service(self, zeroconf, type, name):
        info = zeroconf.get_service_info(type, name)
        if info:
            addr = socket.inet_ntoa(info.addresses[0])
            self.peers[name] = (addr, info.port)


# -----------------------
# Server
# -----------------------

def handle_client(conn):
    try:
        request = conn.recv(1024).decode()

        if request == "LIST":
            files = os.listdir(SHARED_FOLDER)
            conn.send(json.dumps(files).encode())

        elif request.startswith("GET "):
            filename = request[4:]
            path = os.path.join(SHARED_FOLDER, filename)

            if os.path.exists(path):
                conn.send(b"OK")
                size = os.path.getsize(path)
                conn.send(str(size).encode().ljust(16))

                with open(path, "rb") as f:
                    while chunk := f.read(BUFFER_SIZE):
                        conn.sendall(chunk)
            else:
                conn.send(b"NOTFOUND")
    except:
        pass
    finally:
        conn.close()


def start_server(port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("0.0.0.0", port))
    server.listen()

    while True:
        conn, _ = server.accept()
        threading.Thread(target=handle_client, args=(conn,), daemon=True).start()


# -----------------------
# Client
# -----------------------

def list_files(peer):
    ip, port = peer
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((ip, port))
    s.send(b"LIST")
    data = s.recv(65536)
    s.close()
    return json.loads(data.decode())


def download_file(peer, filename, save_path, progress_callback):
    ip, port = peer
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((ip, port))
    s.send(f"GET {filename}".encode())

    response = s.recv(8)

    if response != b"OK":
        s.close()
        return False

    size = int(s.recv(16).decode().strip())
    received = 0

    with open(save_path, "wb") as f:
        while received < size:
            chunk = s.recv(BUFFER_SIZE)
            if not chunk:
                break
            f.write(chunk)
            received += len(chunk)
            progress_callback(received, size)

    s.close()
    return True


# -----------------------
# GUI
# -----------------------

class P2PApp:
    def __init__(self, root):
        self.root = root
        self.root.title("P2P LAN Share")
        self.root.geometry("700x400")

        os.makedirs(SHARED_FOLDER, exist_ok=True)

        self.port = random.randint(50000, 51000)
        self.hostname = socket.gethostname()
        self.ip = get_local_ip()

        self.zeroconf = Zeroconf()
        self.listener = PeerListener()
        ServiceBrowser(self.zeroconf, SERVICE_TYPE, self.listener)

        info = ServiceInfo(
            SERVICE_TYPE,
            f"{self.hostname}.{SERVICE_TYPE}",
            addresses=[socket.inet_aton(self.ip)],
            port=self.port,
        )

        self.zeroconf.register_service(info)
        threading.Thread(target=start_server, args=(self.port,), daemon=True).start()

        self.create_layout()
        self.auto_refresh()

    # ---------------- Layout ----------------

    def create_layout(self):
        main = ttk.Frame(self.root, padding=10)
        main.pack(fill="both", expand=True)

        main.columnconfigure(0, weight=1)
        main.columnconfigure(1, weight=1)
        main.rowconfigure(0, weight=1)

        # Peers
        peer_frame = ttk.LabelFrame(main, text="Peers")
        peer_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 5))

        self.peer_list = tk.Listbox(peer_frame)
        self.peer_list.pack(fill="both", expand=True, padx=5, pady=5)
        self.peer_list.bind("<Double-Button-1>", lambda e: self.show_files())

        # Files
        file_frame = ttk.LabelFrame(main, text="Files")
        file_frame.grid(row=0, column=1, sticky="nsew", padx=(5, 0))

        self.file_list = tk.Listbox(file_frame)
        self.file_list.pack(fill="both", expand=True, padx=5, pady=5)
        self.file_list.bind("<Double-Button-1>", lambda e: self.download_selected())

        # Bottom bar
        bottom = ttk.Frame(self.root, padding=5)
        bottom.pack(fill="x")

        self.progress = ttk.Progressbar(bottom, length=200)
        self.progress.pack(side="left", padx=5)

        self.status = ttk.Label(bottom, text="Ready")
        self.status.pack(side="left", padx=10)

        refresh_btn = ttk.Button(bottom, text="Refresh", command=self.refresh_peers)
        refresh_btn.pack(side="right")

    # ---------------- Logic ----------------

    def auto_refresh(self):
        self.refresh_peers()
        self.root.after(3000, self.auto_refresh)

    def refresh_peers(self):
        self.peer_list.delete(0, tk.END)
        for name in self.listener.peers:
            self.peer_list.insert(tk.END, name)

    def get_selected_peer(self):
        sel = self.peer_list.curselection()
        if not sel:
            return None
        name = self.peer_list.get(sel[0])
        return self.listener.peers.get(name)

    def show_files(self):
        peer = self.get_selected_peer()
        if not peer:
            return

        try:
            files = list_files(peer)
            self.file_list.delete(0, tk.END)
            for f in files:
                self.file_list.insert(tk.END, f)
            self.status.config(text="Files loaded")
        except:
            self.status.config(text="Failed to load files")

    def download_selected(self):
        peer = self.get_selected_peer()
        if not peer:
            return

        sel = self.file_list.curselection()
        if not sel:
            return

        filename = self.file_list.get(sel[0])
        save_path = filedialog.asksaveasfilename(initialfile=filename)
        if not save_path:
            return

        self.progress["value"] = 0
        self.status.config(text="Downloading...")

        def progress_callback(received, total):
            percent = (received / total) * 100
            self.progress["value"] = percent
            self.root.update_idletasks()

        def run_download():
            success = download_file(peer, filename, save_path, progress_callback)
            self.status.config(text="Download complete" if success else "Download failed")

        threading.Thread(target=run_download, daemon=True).start()


# -----------------------
# Run
# -----------------------

if __name__ == "__main__":
    root = tk.Tk()
    app = P2PApp(root)
    root.mainloop()
